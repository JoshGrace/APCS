package com.eimacs.lab05gui;

import com.eimacs.lab05.*;

/**
 *
 * @author |Your name|
 * @version 1.0 |Today's date|
 */
public class Lab05Runner
{
    /**
     * The main method
     * 
     * @param args the command line arguments
     */
	private static TurtleWindow theTurtleWindow;
    public static void main( String[] args )
    {
    	theTurtleWindow = new TurtleWindow();
    }
    
}
