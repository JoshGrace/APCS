package com.eimacs.lab07;

import java.util.ArrayList;
/**
 *
 * @author |your name|
 * @version 1.0 |today's date|
 */
public class InsertionSort extends Sort {
	public <T extends Comparable<T>> void sortList(ArrayList<T> arr) {
		for(int i = 0; i < arr.size(); i++){
	        for(int k = i; k < arr.size(); k++){
	            if(arr.get(k).compareTo(arr.get(i)) < 0){
	                T t = arr.get(k);
	                arr.remove(k);
	                arr.add(i, t);
	            }
	        }
	    }  
	}
}