package com.eimacs.lab08;

/**
 * Card.java
 *
 * <code>Card</code> represents a playing card.
 *
 * @author |Your name|
 * @version 1.0 |Today's date|
 */
public class Card 
{ 
  String rank = "";
  String suit = "";
  int pointValue = 0;
  
  public Card(String Rank, String Suit, int Value){
      rank = Rank;
      suit = Suit;
      pointValue = Value;
  }
  public String getRank(){
      return rank;
  }
  public String getSuit(){
      return suit;
  }
  public int getPointValue(){
      return pointValue;
  }
  public boolean matches(Card c){
      if(c != null && getRank().equals(c.getRank()) && getSuit().equals(c.getSuit()) && getPointValue() == c.getPointValue()){
          return true;
      }
      return false;
  }
  public String toString(){
      return getRank() + " of " + getSuit() + " (point value = " + getPointValue() + ")";
  }  
} 