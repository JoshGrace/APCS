package com.eimacs.lab08;

import java.util.ArrayList;
import com.eimacs.lab08.*;

public class ElevensBoard extends Board
{
  private static final int BOARD_SIZE = 9;
  private static final String[] RANKS =
    { "ace", "2", "3", "4", "5", "6", "7", "8", "9",
      "10", "jack", "queen", "king" };
  private static final String[] SUITS =
    { "spades", "hearts", "diamonds", "clubs" };
  private static final int[] POINT_VALUES = 
    { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 0, 0 };

  public ElevensBoard()
  {
    super(BOARD_SIZE, RANKS, SUITS, POINT_VALUES);
  } 

  public boolean isLegal(ArrayList<Integer> selectedCards)
  {
    if (selectedCards.size() == 2)
    {
      return containsPairSum11(selectedCards);
    }
    else if (selectedCards.size() == 3)	
    {
      return containsJQK(selectedCards);
    }
    else
    {
      return false;
    }
  }

  public boolean anotherPlayIsPossible()
  {
    ArrayList<Integer> cIndexes = getCardIndexes();
    return containsPairSum11(cIndexes) || 
           containsJQK(cIndexes);
  }

  private boolean containsPairSum11(
                      ArrayList<Integer> selectedCards)
  {
    for (int sk1 = 0; sk1 < selectedCards.size(); sk1++)
    {
      int k1 = selectedCards.get(sk1).intValue();
      for (int sk2 = sk1+1; sk2 < selectedCards.size(); sk2++)
      {
        int k2 = selectedCards.get(sk2).intValue();
        if (getCardAt(k1).getPointValue() + 
            getCardAt(k2).getPointValue() == 11)
        {
          return true;
        }
      }
    }
    return false;
  }

  private boolean containsJQK(ArrayList<Integer> selectedCards)
  {
    boolean foundJack = false;
    boolean foundQueen = false;
    boolean foundKing = false;
    for (Integer kObj : selectedCards)
    {
      int k = kObj.intValue();
      if (getCardAt(k).getRank().equals("jack"))
      {
        foundJack = true;
      }
      else if (getCardAt(k).getRank().equals("queen"))
      {
        foundQueen = true;
      }
      else if (getCardAt(k).getRank().equals("king"))
      {
        foundKing = true;
      }
    }
    return foundJack && foundQueen && foundKing;
  }
}